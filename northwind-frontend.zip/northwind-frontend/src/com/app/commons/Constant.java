/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.commons;

/**
 *
 * @author ahza0
 */
public class Constant {

    /**
     *
     */
    //"http://pemrograman2.ddns.net:8080/swagger-ui.html"
    //"http://localhost:8080/swagger-ui.html"
    public static final String BASE_URL = ("http://pemrograman2.ddns.net:8080/swagger-ui.html");
}
